<div id="footer" class="color-div">
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="widget">
						<h4 class="widget-title">Instagram Feed</h4>
						<div id="beta-instagram-feed"><div></div></div>
					</div>
				</div>
				<div class="col-sm-2">
					<div class="widget">
						<h4 class="widget-title">Information</h4>
						<div>
							<ul>
								<li><a href="http://ct14a1.890m.com/"><i class="fa fa-chevron-right"></i> Web Design</a></li>
								<li><a href="http://ct14a1.890m.com/"><i class="fa fa-chevron-right"></i> Web development</a></li>
								<li><a href="http://ct14a1.890m.com/"><i class="fa fa-chevron-right"></i> Marketing</a></li>
								<li><a href="http://ct14a1.890m.com/"><i class="fa fa-chevron-right"></i> Tips</a></li>
								<li><a href="http://ct14a1.890m.com/"><i class="fa fa-chevron-right"></i> Resources</a></li>
								<li><a href="http://ct14a1.890m.com/"><i class="fa fa-chevron-right"></i> Illustrations</a></li>
							</ul>
						</div>
					</div>
				</div>
				<div class="col-sm-4">
				 <div class="col-sm-10">
					<div class="widget">
						<h4 class="widget-title">Contact Us</h4>
						<div>
							<div class="contact-info">
								<i class="fa fa-map-marker"></i>
								<p><a href="{{route('lienhe')}}">Location in the Map</a></p>
								<p>33 Xô Viết Nghệ Tĩnh - Đà Nẵng Phone: 01.648.638.658</p>
							</div>
						</div>
					</div>
				  </div>
				</div>
				<div class="col-sm-3">
					<div class="widget">
						<h4 class="widget-title">Newsletter Subscribe</h4>
						<form action="#" method="post">
							<input type="email" name="your_email">
							<button class="pull-right" type="submit">Subscribe <i class="fa fa-chevron-right"></i></button>
						</form>
					</div>
				</div>
			</div> <!-- .row -->
		</div> <!-- .container -->
	</div> <!-- #footer -->
	<div class="copyright">
		<div class="container">
			<p class="pull-left">Shop bánh online | Bánh kẹo online | . (&copy;) 2017 </p>
			<p class="pull-right pay-options">
				<a href=" http://facebook.com/DuyRNT" target="_blank"><img style="width: 30px;height: 30px;line-height: 30px;margin-top: 10px;" src="source/image/facebook-256.png" alt="" /></a>
				<a href=" http://twitter.com/Duy_RNT" target="_blank"><img style="width: 30px;height: 30px;line-height: 30px;margin-top: 10px;" src="source/image/twitter-icon-9.png" alt="" /></a>
				<a href="https://plus.google.com/101476865900745011574" target="_blank"><img style="width: 30px;height: 30px;line-height: 30px;margin-top: 10px;" src="source/image/7-128.png" alt="" /></a>
				<a href="https://www.youtube.com/channel/UCyNzr2FnPyf3E2H7QefgMww" target="_blank"><img style="width: 30px;height: 30px;line-height: 30px;margin-top: 10px;" src="source/image/YouTube-icon-full_color.png" alt="" /></a>
			</p>
			<div class="clearfix"></div>
		</div> <!-- .container -->
	</div> <!-- .copyright -->